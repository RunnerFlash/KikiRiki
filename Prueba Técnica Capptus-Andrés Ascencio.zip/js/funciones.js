
(function() {
  "use strict";

 
  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

 
  const onscroll = (el, listener) => {
    el.addEventListener('scroll', listener)
  }

  
  let backtotop = select('.back-to-top')
  if (backtotop) {
    const toggleBacktotop = () => {
      if (window.scrollY > 100) {
        backtotop.classList.add('active')
      } else {
        backtotop.classList.remove('active')
      }
    }
    window.addEventListener('load', toggleBacktotop)
    onscroll(document, toggleBacktotop)
  }

 
  let countdown = select('.countdown');
  const output = countdown.innerHTML;

  const countDownDate = function() {
    let timeleft = new Date(countdown.getAttribute('data-count')).getTime() - new Date().getTime();

    let days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
    let hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((timeleft % (1000 * 60)) / 1000);

    countdown.innerHTML = output.replace('%d', days).replace('%h', hours).replace('%m', minutes).replace('%s', seconds);
  }
  countDownDate();
  setInterval(countDownDate, 1000);

})()

function validar(){

      var fo = document.forms["autentica"];

      var n = fo["name"];
      if(n.value.length < 1){

        alert("Este campo es requerido, llenelo de favor");
        n.focus();
        n.setAttribute("required");
        return false;
      }

       var n = fo["last_name"];
      if(n.value.length < 1){

        alert("Este campo es requerido, llenelo de favor");
        n.focus();
        n.setAttribute("required");
        return false;
      }
      
      var a = fo["email"];
      if (a.value.length < 1) {

        alert("Este campo es requerido, llenelo de favor");
        a.focus();
        a.setAttribute("required");
        return false;
      }

        var a = fo["number"];
      if (a.value.length < 1) {

        alert("Este campo es requerido, llenelo de favor");
        a.focus();
        a.setAttribute("required");
        return false;
      }

       var a = fo["subject"];
      if (a.value.length < 1) {

        alert("Este campo es requerido, llenelo de favor");
        a.focus();
        a.setAttribute("required");
        return false;
      }

       var a = fo["message"];
      if (a.value.length < 1) {

        alert("Este campo es requerido, llenelo de favor");
        a.focus();
        a.setAttribute("required");
        return false;
      }

      return true;
      }


function acentos(e) {
    tecla = (document.all) ? e.keyCode : e.which;

    
    if (tecla == 8) {
        return true;
    }

    
    patron = /[A-Za-z0-9]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
}

function numeros(e) {
    tecla = (document.all) ? e.keyCode : e.which;

    
    if (tecla == 8) {
        return true;
    }

    
    patron = /[0-9]/ ;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
}